import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import nodemailer from 'https://deno.land/x/nodemailer@1.0.0/mod.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { to, subject, html, userId } = await req.json()

    // Hole SMTP-Konfiguration aus der Datenbank
    const { data: settings, error: settingsError } = await supabaseClient
      .from('user_settings')
      .select('smtp_config')
      .eq('user_id', userId)
      .single()

    if (settingsError) throw settingsError
    if (!settings?.smtp_config) throw new Error('Keine SMTP-Konfiguration gefunden')

    const smtpConfig = settings.smtp_config

    // Erstelle Transporter
    const transporter = nodemailer.createTransport({
      host: smtpConfig.host,
      port: parseInt(smtpConfig.port),
      secure: smtpConfig.useTLS,
      auth: {
        user: smtpConfig.username,
        pass: smtpConfig.password
      }
    })

    // Sende E-Mail
    const info = await transporter.sendMail({
      from: smtpConfig.fromEmail,
      to,
      subject,
      html
    })

    return new Response(
      JSON.stringify({ success: true, messageId: info.messageId }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
}) 